<?php
//Array Numerik => Index dan Value
$domisili = ["Jakarta", "Bogor", "Depok", "Tangerang", "Bekasi"];

//Array Assosiative => Pasangan Key dan Value
$program_studi = [
    "SI" => "Sistem Informasi",
    "TI" => "Teknik Informatika",
    "BD" => "Bisnis Digital"
];

$skills = [
    "HTML" => 10,
    "CSS" => 10,
    "Javascript" => 20,
    "RWD Bootstrap" => 20,
    "PHP" => 30,
    "Python" => 30,
    "Java" => 50
];
